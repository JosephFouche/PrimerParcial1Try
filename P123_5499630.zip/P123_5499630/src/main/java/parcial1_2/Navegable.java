
package parcial1_2;
/*
 *
 * @author EMG73
 */

public interface Navegable {
    String navegar(String link);
}

